<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\Event;
use App\Models\Galeri; 
use Illuminate\Http\Request;
use Inertia\Inertia;

class MenuController extends Controller
{

    public function index()
    {

        $favoriteMenus = Menu::where('favorit', 'Y')
                            ->orderBy('updated_at', 'desc')
                            ->take(4)
                            ->get();

        $events = Event::orderBy('tanggal', 'desc')
                       ->take(3)
                       ->get();

        // Ambil gambar yang difavoritkan untuk Home
        $favorites = Galeri::where('is_favorite', true)
                        ->latest()
                        ->take(8) // Ambil cukup banyak untuk display, misal 8
                        ->get();
        
        return Inertia::render('Home', [
            'events' => $events,
            'favoriteMenus' => $favoriteMenus,
            'galleries' => [
                'favorites' => $favorites, 
            ],
        ]);
    }

    public function gallery()
    {
        // Ambil gambar yang TIDAK difavoritkan untuk halaman Gallery
        $images = Galeri::where('is_favorite', false)->latest()->get();

        return Inertia::render('Gallery', [
            'images' => $images
        ]);
    }
    public function showMenu()
    {
        $allMenus = Menu::all();

        $menus = [
            'makanan' => $allMenus->whereIn('kategori', ['makanan', 'camilan'])->values(),
            'minuman' => $allMenus->whereIn('kategori', ['coffee', 'non-coffee'])->values(),
        ];

        return Inertia::render('HalamanMenu', [
            'menus' => $menus,
        ]);
    }
}