<script setup>
import Modal from '@/Components/Modal.vue';
import SecondaryButton from '@/Components/SecondaryButton.vue';

// Props dari database
defineProps({
  show: {
    type: Boolean,
    default: false,
  },
  item: {
    type: Object,
    default: () => ({}),
  },
});

const emit = defineEmits(['close']);

const defaultEventImage = '/images/placeholder-event.jpg';

const close = () => {
  emit('close');
};
</script>

<template>
  <Modal :show="show" @close="close" maxWidth="md">
    <div class="p-6 bg-white dark:bg-gray-800 rounded-lg">
      <!-- Judul Event -->
      <h2 class="text-2xl font-bold mb-4 text-gray-900 dark:text-gray-100">
        {{ item?.nama_event || 'Detail Event' }}
      </h2>

      <div class="flex flex-col gap-4">
        <!-- Gambar Event -->
        <div>
          <img
            :src="item?.gambar_url || defaultEventImage"
            :alt="item?.nama_event || 'Gambar Event'"
            class="rounded-lg shadow-md w-full h-48 object-cover bg-gray-300 dark:bg-gray-700 mb-4"
          >
        </div>

        <!-- Deskripsi -->
        <div>
          <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">Deskripsi:</p>
          <p class="text-gray-700 dark:text-gray-300 leading-relaxed">
            {{ item?.deskripsi_event || 'Deskripsi event belum tersedia.' }}
          </p>
        </div>
      </div>

      <!-- Tanggal dan Waktu -->
      <div class="mt-4 text-xs text-gray-500 dark:text-gray-400 border-t pt-2 dark:border-gray-600">
        <p v-if="item?.tanggal">Tanggal: {{ formatDate(item.tanggal) }}</p>
        <p v-if="item?.waktu">Waktu: {{ formatTime(item.waktu) }} WIB</p>
      </div>

      <!-- Tombol Tutup -->
      <div class="mt-6 flex justify-end">
        <SecondaryButton @click="close">
          Tutup
        </SecondaryButton>
      </div>
    </div>
  </Modal>
</template>

<script>
export default {
  methods: {
    formatDate(dateString) {
      if (!dateString || dateString === '0000-00-00' || dateString === 'null') {
        return 'Tanggal tidak valid';
      }
      const options = { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' };
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return 'Tanggal tidak valid';
      }
      return date.toLocaleDateString('id-ID', options);
    },
    formatTime(timeString) {
      if (!timeString || timeString === 'null') {
        return '--:--';
      }
      const parts = timeString.split(':');
      if (parts.length >= 2) {
        return `${parts[0]}:${parts[1]}`;
      }
      return timeString;
    },
  },
};
</script>

<style scoped>
img {
  max-height: 200px;
}
</style>
