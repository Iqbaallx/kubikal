<script setup>
// Tidak ada script khusus yang diperlukan untuk footer ini
</script>

<template>
    <footer class="bg-gray-800 dark:bg-black text-gray-400 dark:text-gray-500 py-8 px-4 text-center mt-auto">
        <div class="mb-4">
            <a href="#" class="inline-block mx-2 hover:text-white dark:hover:text-gray-300">FB</a>
            <a href="#" class="inline-block mx-2 hover:text-white dark:hover:text-gray-300">IG</a>
            <a href="#" class="inline-block mx-2 hover:text-white dark:hover:text-gray-300">TW</a>
        </div>
        <p class="text-sm">&copy; {{ new Date().getFullYear() }} Kubikal Space. All rights reserved.</p>
    </footer>
</template>